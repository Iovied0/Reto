package agenciaViajes.bbdd.gestores;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import agenciaViajes.bbdd.Config.DBUtils;
import agenciaViajes.bbdd.pojos.Agencia;

public class GestorAgencia {
	public void insertEjemplo(Agencia agencia) {
	    Connection connection = null;
	    PreparedStatement stmt = null;

	    try {
	        Class.forName(DBUtils.DRIVER);
	        connection = DriverManager.getConnection(DBUtils.URL, DBUtils.USER, DBUtils.PASS);

	    
	        String sql = "INSERT INTO Agencia (nombre, logo, color, numero_empleados, limite_empleados, tipo_agencia) VALUES (?, ?, ?, ?, ?, ?)";
	        stmt = connection.prepareStatement(sql);
	        stmt.setString(1, agencia.getNombre());
	        stmt.setString(2, agencia.getLogo());
	        stmt.setString(3, agencia.getColor());
	        stmt.setString(4, agencia.getNumeroEmpleados());
	        stmt.setString(5, agencia.getLimiteEmpleadosCodigo()); 
	        stmt.setString(6, agencia.getTipoAgencia().getCodigo());

	        stmt.executeUpdate();

	    } catch (SQLException sqle) {
	        System.err.println("Error con la BBDD: " + sqle.getMessage());
	        sqle.printStackTrace();
	    } catch (Exception e) {
	        System.err.println("Error genérico: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        try {
	            if (stmt != null) stmt.close();
	            if (connection != null) connection.close();
	        } catch (Exception e) {
	            System.err.println("Error al cerrar recursos: " + e.getMessage());
	        }
	    }
	}
}

