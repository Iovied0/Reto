package agenciaViajes.vista.panel;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JFrame {

	public Login() {
        setTitle("Login - Viajes Erreka-Mari");
        setSize(1100, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 10, 10));

        // Campo de usuario
        JLabel labelUsuario = new JLabel("Nombre de Agencia");
        JTextField textUsuario = new JTextField();
        panel.add(labelUsuario);
        panel.add(textUsuario);

        // Campo de contrasenia
        JLabel labelPassword = new JLabel("Contraseña");
        JPasswordField textPassword = new JPasswordField();
        panel.add(labelPassword);
        panel.add(textPassword);

        // Boton para iniciar sesion
        JButton btnLogin = new JButton("Iniciar Sesión");
        btnLogin.addActionListener(e -> {
            String usuario = textUsuario.getText();
            String password = new String(textPassword.getPassword());

            if (usuario.equals("travel") && password.equals("123")) { // Validacion simulada
                JOptionPane.showMessageDialog(this, "Inicio de sesion exitoso.", "Exito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Credenciales incorrectas.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Boton para crear Nueva Agencia
        JButton btnNuevaAgencia = new JButton("Crear Nueva Agencia");
        btnNuevaAgencia.addActionListener(e -> {
            NuevaAgencia nuevaAgencia = new NuevaAgencia();
            nuevaAgencia.setVisible(true);
            dispose();
        });
        
        panel.add(btnLogin);
        panel.add(btnNuevaAgencia);

        add(panel, BorderLayout.CENTER);
    }    
}
