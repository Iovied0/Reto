-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 30-01-2025 a las 16:54:45
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `g2_r2_dam_1`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agencia`
--

CREATE TABLE `agencia` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `logo` varchar(250) NOT NULL,
  `color` char(7) NOT NULL,
  `numero_empleados` varchar(50) NOT NULL,
  `limite_empleados` char(2) DEFAULT NULL,
  `tipo_agencia` char(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `agencia`
--

INSERT INTO `agencia` (`id`, `nombre`, `logo`, `color`, `numero_empleados`, `limite_empleados`, `tipo_agencia`) VALUES
(39, 'AOURAGH TOUR', 'https://www.senderismo.net/media/4854132/s-cape-travel-_-cabo-de-gata_-amatistas-(65)-(Medium).jpg', '#FFCC33', 'Entre 100 y 1000 empleados', 'L3', 'A3'),
(40, 'BILBAO TOUR', 'https://cdfb53915d.cbaul-cdnwnd.com/af97a72149084b8ecf3b018babd15a36/200000001-805a1824e3/67932817_3-VIAJES-Y-TURISMO-UNIVERSALTRAVEL123-Planeamiento-de-eventos.jpg', '#99FF33', 'Entre 10 y 100 empleados', 'L2', 'A2');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `agencia`
--
ALTER TABLE `agencia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `num_empleados` (`limite_empleados`),
  ADD KEY `tipo_agencia` (`tipo_agencia`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `agencia`
--
ALTER TABLE `agencia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `agencia`
--
ALTER TABLE `agencia`
  ADD CONSTRAINT `agencia_ibfk_1` FOREIGN KEY (`limite_empleados`) REFERENCES `numeroempleados` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `agencia_ibfk_2` FOREIGN KEY (`tipo_agencia`) REFERENCES `tiposagencia` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
